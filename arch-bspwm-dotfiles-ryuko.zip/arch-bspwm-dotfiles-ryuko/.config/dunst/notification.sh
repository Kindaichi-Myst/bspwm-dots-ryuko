#!/bin/sh
paplay $HOME/.config/dunst/notification.wav
