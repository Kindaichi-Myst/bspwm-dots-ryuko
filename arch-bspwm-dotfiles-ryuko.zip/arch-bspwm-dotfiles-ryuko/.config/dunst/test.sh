#!/bin/bash
killall dunst;notify-send foo
